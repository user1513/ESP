rm *.pem -rf
rm *.srl -rf
rm *.h -rf
rm *.cer -rf
rm *.key_1024 -rf
rm *.req -rf
rm *.conf -rf
rm *.bak -rf

rm ca/ -rf
rm bin/ -rf
rm server/ -rf
rm client/ -rf
rm include/ -rf
 
 

